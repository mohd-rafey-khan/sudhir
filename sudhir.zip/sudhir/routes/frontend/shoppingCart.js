var Cart = require("../../services/cart");
const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
// var back = require("express-back");
var nodemailer = require("nodemailer");
const _ = require("lodash");

router.get('/add-to-cart/:id', function(req, res, next){
    //var backurl=req.header('Referer') || "/";
    if(req.session.customer != undefined && req.session.customer!=null) {
            var productId = req.params.id;
            var cart = new Cart(req.session.cart ? req.session.cart : {});
            var products = [];

            con.query("SELECT * FROM product WHERE id = ?",[productId], function (err, product) {
                if (err) throw err;
            //   products = result;
                if(product.length >0 ){
                    var pid = product[0].id;

                    if(req.session.cart == undefined || Object.keys(req.session.cart) == 0) {
                        cart.add(product[0], product[0].id);
                        req.session.cart = cart;
                    }

                    else if(!(Object.keys(req.session.cart.items).includes(pid.toString()))) {
                        console.log((!(Object.keys(req.session.cart.items).includes(pid.toString()))));
                        cart.add(product[0], product[0].id);
                        req.session.cart = cart;
                    }
                }
               return res.send(true);
            });
    } else {
           // return res.send(false);
    }
  });

  router.get('/shopping-cart', function(req, res, next) {
      console.log(req.session.cart.items);
    if(req.session.customer != undefined && req.session.customer!=null) {
        if (!req.session.cart) {
            return res.render('frontend/shoppingCart', {products: null, totalQty:0});
        }
        var cart = new Cart(req.session.cart);
        res.render('frontend/shoppingCart', {products: cart.generateArray(), totalQty: cart.totalQty});
    } else {
        res.redirect("/login");
    }
  });

  router.get('/remove/:id', function(req, res, next) {
    if(req.session.customer != undefined && req.session.customer!=null) {
      var productId = req.params.id;
      var cart = new Cart(req.session.cart ? req.session.cart : {});
      cart.removeItem(productId);
      req.session.cart = cart;
      res.redirect('/shopping-cart');
    } else {
        res.redirect("/login");
    }
  });

  router.get("/checkout", function(req, res) {
    if(req.session.customer != undefined && req.session.customer!=null) {
        var productsInCart  = Object.keys(req.session.cart.items);
        var productIds = "";
        var pinfo = "";
        productsInCart.forEach(element => {
            productIds = productIds +" "+ element;
            pinfo = _.camelCase(req.session.cart.items[element].item.name)+"|"+_.camelCase(req.session.cart.items[element].item.code)+" "+pinfo;
        });
        productIds =  productIds.trim();
        pinfo = pinfo.trim();
       // console.log(pinfo);
        // var transporter = nodemailer.createTransport({
        //     host: 'mail.sudhirenterprises.in',
        //     port: 465,
        //     auth: {
        //       user: 'noreply@sudhirenterprises.in',
        //       pass: 'webmail@12345'
        //     }
        //   });
          
        //   var mailOptions = {
        //     from: 'noreply@sudhirenterprises.in',
        //     to: 'sudhirenterprises941@gmail.com',
        //     subject: 'New Order Received',
        //     text: "New order placed\nName:\t"+req.session.customer.name+"\nNumber:\t"+req.session.customer.number+""
        //   };
          
        //   transporter.sendMail(mailOptions, function(error, info){
        //     if (error) {
        //       console.log(error);
        //     } else {
        //       console.log('Email sent: ' + info.response);
        //     }
        //   });

        con.query("INSERT INTO orderhistory (user_name, user_contact, products, pinfo) VALUES (?,?, ?, ?)",[req.session.customer.name, req.session.customer.number, productIds, pinfo], function(err) {
            if(err) throw err;
            req.session.cart = null;
            res.render("frontend/thnx");
        });
      } else {
          res.redirect("/login");
      }
  });

  // router.get("/thnx", function(req, res) {
  //   res.render("frontend/thnx");
  // })

module.exports = router;
