const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
const path = require('path');
var fs = require("fs");

router.get("/addcategory",function (req,res) {
  var query = "SELECT * FROM category";
  con.query(query,function(err,respond) {
    res.render("admin/addcategory.ejs",{data:respond});
  });
});

router.post("/addcategory",function(req,res) {


  if(req.files){
    var filename = req.files.prodimg.name;
    let sampleFile = req.files.prodimg;
    var dirpath = "../../public/upload/category/"+filename;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {
          if (err)
          return res.status(500).send(err);
      });
  }

  var name = req.body.category;
  con.query("INSERT INTO category (name) VALUES (?)",[name], function(err) {
    if(err) throw err;
    res.redirect("/admin/addcategory");
  });
});

router.post("/catdel",function(req,res) {
  var deleteid = req.body.id;
  con.query("SELECT * FROM category WHERE id = ?", [deleteid] ,function(e, result) {
    fs.unlink("./public/upload/category/"+result[0].image, (err => { 
      if (err) console.log(err);  
      else {
        var query = "DELETE FROM category WHERE id = ?";
        con.query(query,[deleteid], function (err, result) {
         if (err) throw err;
         res.redirect("/admin/addcategory");
       });
      }
    }));
  });
});

router.post("/updcatimg",function(req,res) {
  console.log(req.files);
  if(req.files){
    var filename = req.files.updcatimg.name;
    let sampleFile = req.files.updcatimg;
    var dirpath = "../../public/upload/category/"+filename;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {
          if (err)
          return res.status(500).send(err);
      });
  }
  var id = req.body.id;
  con.query("SELECT * FROM category WHERE id = ?",[id], function(e, respp) {
      if(respp[0].image != null && respp[0].image != "") {
        fs.unlink("./public/upload/category/"+respp[0].image, (err => { 
          if (err) console.log(err);  
        }));
      }
  });
  var query = "UPDATE category SET image = ? WHERE id = ?";
  con.query(query,[filename,id],function(err,respond) {
     if(err) throw err;
     res.redirect("/admin/addcategory");
  });
});

module.exports = router;
