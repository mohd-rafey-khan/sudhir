const express = require('express');
var router  = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
var fs = require("fs");

router.get("/getproduct",function(req,res) {
  var query = "SELECT * FROM product";
  con.query(query,function(err,respond) {
    if(err) throw err;
    res.render("admin/getproduct",{data:respond});
  });
});
router.post("/updatename",function(req,res) {
  var id = req.body.id;
  var name = req.body.name;
  var query = "UPDATE product SET name = ? WHERE id = ?";
  con.query(query,[name,id],function(err,respond) {
    if(err) throw err;
    res.redirect("/admin/getproduct");
  });
});
router.post("/updatetag",function(req,res) {
  var id = req.body.id;
  var tag = req.body.tag;
  console.log(tag);
  var query = "UPDATE product SET tag = ? WHERE id = ?";
  con.query(query,[tag,id],function(err,respond) {
    if(err) throw err;
    console.log("success  "+tag);
    res.redirect("/admin/getproduct");
  });
});
router.post("/upproddel",function(req,res) {
  var id  = req.body.id;

  con.query("SELECT * FROM product WHERE id = ?", [id] ,function(e, result) {
    fs.unlink("./public/upload/product/"+result[0].image, (err => { 
      if (err) console.log(err);  
      else {
       
        var query = "DELETE FROM product WHERE id = ?";
        con.query(query,[id],function(err,respond) {
          if(err) throw err;
          res.redirect("/admin/getproduct");
        });
      }
    }));
  });
});

router.post("/selectdel",function(req,res) {
  if(req.body.id_all == ''){
    res.redirect("/admin/getproduct");
  }else{
     var all_id = req.body.id_all.split(",");
     all_id.forEach(function(id) {
      con.query("SELECT * FROM product WHERE id = ?", [id] ,function(e, result) {
        fs.unlink("./public/upload/product/"+result[0].image, (err => { 
          if (err) console.log(err);  
          else {
           
            var query = "DELETE FROM product WHERE id = ?";
            con.query(query,[id],function(err,respond) {
              if(err) throw err;
              
            });
          }
        }));
      });

      
        // var query = "DELETE FROM product WHERE id = ?";
        // con.query(query,[id],function(err,repond) {
        //   if(err) throw err;
        // });
     });
     res.redirect("/admin/getproduct");
  }
});
module.exports = router;
