const mysql = require("mysql2");

let connection = mysql.createConnection({
    host: "103.227.176.29",
    user: "sudhiren_root",
    password: 'sudhirent@456',
    database: "sudhiren_commercial"
});

connection.connect(function(err) {
    if (err) throw err;
    console.log("Database connected!");
});

module.exports = connection;
